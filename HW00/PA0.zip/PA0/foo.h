/****************************************************************
 *
 * Author: Justin Bradley
 * Title: foo.h
 * Date: Thursday, January 16, 2020
 * Description: header file for foo 
 *
 ****************************************************************/
int print_msg(char * msg);
