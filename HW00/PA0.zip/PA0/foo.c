#include <stdio.h>
#include "foo.h"

int print_msg(char * msg)
{
		printf("%s", msg);
		return 0;
}
